#include <iostream>
using namespace std;
class DllNode
{
public:
    int data;
    DllNode *next;
    DllNode *prev;

    DllNode(int data) : data(data), next(nullptr), prev(nullptr) {}
};
class DLL
{
private:
    DllNode *head;

public:
    DLL() : head(nullptr) {}
    DllNode *createNode(int data)
    {
        return new DllNode(data);
    }
    void insertAtBeginning(int data)
    {
        DllNode *newNode = createNode(data);
        if (head == nullptr)
        {
            head = newNode;
        }
        else
        {
            newNode->next = head;
            head->prev = newNode;
            head = newNode;
        }
    }
    void insertAtEnd(int data)
    {
        DllNode *newNode = createNode(data);
        if (head == nullptr)
        {
            head = newNode;
        }
        else
        {
            DllNode *temp = head;
            while (temp->next != nullptr)
            {
                temp = temp->next;
            }
            temp->next = newNode;
            newNode->prev = temp;
        }
    }
    void insertAtPosition(int data, int position)
    {
        if (position == 0)
        {
            insertAtBeginning(data);
            return;
        }

        DllNode *newNode = createNode(data);
        DllNode *temp = head;
        for (int i = 0; i < position - 1 && temp != nullptr; ++i)
        {
            temp = temp->next;
        }

        if (temp == nullptr)
        {
            cout << "Position out of bounds" << endl;
            delete newNode;
            return;
        }

        newNode->next = temp->next;
        if (temp->next != nullptr)
        {
            temp->next->prev = newNode;
        }
        temp->next = newNode;
        newNode->prev = temp;
    }
    void deleteFromBeginning()
    {
        if (head == nullptr)
        {
            cout << "List is empty" << endl;
            return;
        }

        DllNode *temp = head;
        head = head->next;
        if (head != nullptr)
        {
            head->prev = nullptr;
        }
        delete temp;
    }
    void deleteFromEnd()
    {
        if (head == nullptr)
        {
            cout << "List is empty" << endl;
            return;
        }

        DllNode *temp = head;
        if (temp->next == nullptr)
        {
            head = nullptr;

            delete temp;
            return;
        }

        while (temp->next != nullptr)
        {
            temp = temp->next;
        }
        temp->prev->next = nullptr;
        delete temp;
    }
    void deleteFromPosition(int position)
    {
        if (head == nullptr)
        {
            cout << "List is empty" << endl;
            return;
        }

        if (position == 0)
        {
            deleteFromBeginning();
            return;
        }

        DllNode *temp = head;
        for (int i = 0; i < position && temp != nullptr; ++i)
        {
            temp = temp->next;
        }

        if (temp == nullptr)
        {
            cout << "Position out of bounds" << endl;
            return;
        }

        if (temp->prev != nullptr)
        {
            temp->prev->next = temp->next;
        }
        if (temp->next != nullptr)
        {
            temp->next->prev = temp->prev;
        }
        delete temp;
    }
    void traverse()
    {
        DllNode *temp = head;
        while (temp != nullptr)
        {
            cout << temp->data << " <-> ";
            temp = temp->next;
        }
        cout << "NULL" << endl;
    }
    bool search(int data)
    {

        DllNode *temp = head;
        while (temp != nullptr)
        {
            if (temp->data == data)
            {
                return true;
            }
            temp = temp->next;
        }
        return false;
    }
};