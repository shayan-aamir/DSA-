#include <iostream>
#include "maze.cpp"
#include "nqueens.cpp"
#include "sll.cpp"
#include "dll.cpp"
#include "stackusingarray.cpp"
#include "queuearray.cpp"
#include "sort.cpp"
#include "search.cpp"
#include "mergesort.cpp"
#include "quicksort.cpp"
#include "kmp.cpp"
#include "bruteforce.cpp"
#include "rabinkarp.cpp"
#include "bst.cpp"
#include "avltree.cpp"
#include "hashing_chaining.cpp"
#include "hashing_linear.cpp"
#include "hashing_double.cpp"
#include "hashing_quadratic.cpp"
#include "adjacencylist.cpp"
#include "adjacencymatrix.cpp"
#include <cstdlib>
#include <windows.h>
using namespace std;

void clearScreen()
{
    system("cls");
}
bool askToContinue()
{
    char choice;
    cout << "Do you want to continue? (y/n): ";
    cin >> choice;
    clearScreen();
    return (choice == 'y' || choice == 'Y');
}
void waitForKeyPress()
{
    cout << "Press any key to continue...";
    getchar();
}
int main()
{
    cout << "\t\t\t\tWelcome to Data Structures and Algorithms Project!" << endl;
    waitForKeyPress();
    clearScreen();
    while (true)
    {
        int choice;
        cout << "Enter your choice: " << endl;
        cout << "1. Singly Linked List" << endl;
        cout << "2. Doubly Linked List" << endl;
        cout << "3. Stack array" << endl;
        cout << "4. Queue array" << endl;
        cout << "5. Searching Algorithms in an array:" << endl;
        cout << "6. Sorting Algorithms in an array:" << endl;
        cout << "7. String Algorithms:" << endl;
        cout << "8. Binary Search Tree:" << endl;
        cout << "9. AVL Tree:" << endl;
        cout << "10. Rat in a maze(Recursion & backtracking):" << endl;
        cout << "11. N-Queens (Recursion & backtracking)" << endl;
        cout << "12. Hashing with Chaining:" << endl;
        cout << "13. Hashing with Linear Probing:" << endl;
        cout << "14. Hashing with Quadratic Probing:" << endl;
        cout << "15. Hashing with Double Hashing:" << endl;
        cout << "16. Graphs using Adjacency List:" << endl;
        cout << "17. Graphs using Adjacency Matrix:" << endl;
        cout << "0. Exit:" << endl;
        cin >> choice;
        clearScreen();
        if (choice == 1)
        {
            SLL list;
            cout << "\t\t\t\tSingly Link List operations:" << endl;
            while (true)
            {
                int ch;
                cout << "Enter your choice to perform operation:" << endl;
                cout << "1. Insert at Start:" << endl;
                cout << "2. Insert at End:" << endl;
                cout << "3. Insert at Any position:" << endl;
                cout << "4. Delete at Start:" << endl;
                cout << "5. Delete at End:" << endl;
                cout << "6. Delete at Any position:" << endl;
                cout << "7. Display:" << endl;
                cout << "8. Search for a number:" << endl;
                cout << "0. Exit:" << endl;
                cin >> ch;
                clearScreen();

                if (ch == 1)
                {
                    int num;
                    cout << "Enter the number to be inserted at start: " << endl;
                    cin >> num;
                    list.insertAtBeginning(num);
                    if (!askToContinue())
                    {
                        clearScreen();
                        break;
                    }
                }
                else if (ch == 2)
                {
                    int num;
                    cout << "Enter the number to be inserted at end: " << endl;
                    cin >> num;
                    list.insertAtEnd(num);
                    if (!askToContinue())
                    {
                        clearScreen();
                        break;
                    }
                }
                else if (ch == 3)
                {
                    int num, pos;
                    cout << "Enter the position at which the number is to be inserted: " << endl;
                    cin >> pos;
                    cout << "Enter the number to be inserted at " << pos << " position: " << endl;
                    cin >> num;
                    list.insertAtPosition(num, pos);
                    if (!askToContinue())
                    {
                        clearScreen();
                        break;
                    }
                }
                else if (ch == 4)
                {
                    list.deleteFromBeginning();
                    if (!askToContinue())
                    {
                        clearScreen();
                        break;
                    }
                }
                else if (ch == 5)
                {
                    list.deleteFromEnd();
                    if (!askToContinue())
                    {
                        clearScreen();
                        break;
                    }
                }
                else if (ch == 6)
                {
                    int pos;
                    cout << "Enter the position at which the number is to be deleted: " << endl;
                    cin >> pos;
                    list.deleteFromPosition(pos);
                    if (!askToContinue())
                    {
                        clearScreen();
                        break;
                    }
                }
                else if (ch == 7)
                {
                    list.traverse();
                    if (!askToContinue())
                    {
                        clearScreen();
                        break;
                    }
                }
                else if (ch == 8)
                {
                    int num;
                    cout << "Enter the number you want to search:" << endl;
                    cin >> num;
                    if (list.search(num))
                    {
                        cout << "Number found in the list" << endl;
                    }
                    else
                    {
                        cout << "Number not found in the list" << endl;
                    }
                    if (!askToContinue())
                    {
                        clearScreen();
                        break;
                    }
                }
                else if (ch == 0)
                {
                    clearScreen();
                    break;
                }
                else
                {
                    cout << "\t\t\t\tInvalid Choice!\n\t\t\t\tTry again." << endl;
                }
            }
        }
        else if (choice == 2)
        {
            DLL list;
            cout << "\t\t\t\tDoubly Link List operations:" << endl;
            while (true)
            {
                int ch;
                cout << "Enter your choice to perform operation:" << endl;
                cout << "1. Insert at Start:" << endl;
                cout << "2. Insert at End:" << endl;
                cout << "3. Insert at Any position:" << endl;
                cout << "4. Delete at Start:" << endl;
                cout << "5. Delete at End:" << endl;
                cout << "6. Delete at Any position:" << endl;
                cout << "7. Display:" << endl;
                cout << "8. Search for a number:" << endl;
                cout << "0. Exit:" << endl;
                cin >> ch;
                clearScreen();

                if (ch == 1)
                {
                    int num;
                    cout << "Enter the number to be inserted at start: " << endl;
                    cin >> num;
                    list.insertAtBeginning(num);
                    if (!askToContinue())
                    {
                        clearScreen();
                        break;
                    }
                }
                else if (ch == 2)
                {
                    int num;
                    cout << "Enter the number to be inserted at end: " << endl;
                    cin >> num;
                    list.insertAtEnd(num);
                    if (!askToContinue())
                    {
                        clearScreen();
                        break;
                    }
                }
                else if (ch == 3)
                {
                    int num, pos;
                    cout << "Enter the position at which the number is to be inserted: " << endl;
                    cin >> pos;
                    cout << "Enter the number to be inserted at " << pos << " position: " << endl;
                    cin >> num;
                    list.insertAtPosition(num, pos);
                    if (!askToContinue())
                    {
                        clearScreen();
                        break;
                    }
                }
                else if (ch == 4)
                {
                    list.deleteFromBeginning();
                    if (!askToContinue())
                    {
                        clearScreen();
                        break;
                    }
                }
                else if (ch == 5)
                {
                    list.deleteFromEnd();
                    if (!askToContinue())
                    {
                        clearScreen();
                        break;
                    }
                }
                else if (ch == 6)
                {
                    int pos;
                    cout << "Enter the position at which the number is to be deleted: " << endl;
                    cin >> pos;
                    list.deleteFromPosition(pos);
                    if (!askToContinue())
                    {
                        clearScreen();
                        break;
                    }
                }
                else if (ch == 7)
                {
                    list.traverse();
                    if (!askToContinue())
                    {
                        clearScreen();
                        break;
                    }
                }
                else if (ch == 8)
                {
                    int num;
                    cout << "Enter the number you want to search:" << endl;
                    cin >> num;
                    if (list.search(num))
                    {
                        cout << "Number found in the list" << endl;
                    }
                    else
                    {
                        cout << "Number not found in the list" << endl;
                    }
                    if (!askToContinue())
                    {
                        clearScreen();
                        break;
                    }
                }
                else if (ch == 0)
                {
                    clearScreen();
                    break;
                }
                else
                {
                    cout << "\t\t\t\tInvalid Choice!\n\t\t\t\tTry again." << endl;
                }
            }
        }
        else if (choice == 3)
        {
            cout << "\t\t\t\tStack operations:" << endl;
            int size;
            cout << "Enter the size of the Stack:" << endl;
            cin >> size;
            stack st(size);
            while (true)
            {
                int ch;
                cout << "Enter your choice:" << endl;
                cout << "1. Push" << endl;
                cout << "2. Pop" << endl;
                cout << "3. Traverse" << endl;
                cout << "4. Top" << endl;
                cout << "0. Exit:" << endl;
                cin >> ch;
                clearScreen();
                if (ch == 1)
                {
                    int num;
                    cout << "Enter the number to be pushed at stack:" << endl;
                    cin >> num;
                    st.push(num);
                    if (!askToContinue())
                    {
                        clearScreen();
                        break;
                    }
                }
                else if (ch == 2)
                {
                    int t = st.pop();
                    cout << "Popped element is: " << t << endl;
                    if (!askToContinue())
                    {
                        clearScreen();
                        break;
                    }
                }
                else if (ch == 3)
                {
                    st.print();
                    if (!askToContinue())
                    {
                        clearScreen();
                        break;
                    }
                }
                else if (ch == 4)
                {
                    cout << "Top element in stack is: ";
                    int t = st.peek();
                    cout << t << endl;
                    if (!askToContinue())
                    {
                        clearScreen();
                        break;
                    }
                }
                else if (ch == 0)
                {
                    clearScreen();
                    break;
                }
                else
                {
                    cout << "\t\t\t\tInvalid Choice!\n\t\t\t\tTry again." << endl;
                }
            }
        }
        else if (choice == 4)
        {
            cout << "\t\t\t\tQueue operations:" << endl;
            int size;
            cout << "Enter the size of the Queue:" << endl;
            cin >> size;
            Queue q(size);
            while (true)
            {
                int ch;
                cout << "Enter your choice:" << endl;
                cout << "1. Enque" << endl;
                cout << "2. Deque" << endl;
                cout << "3. Traverse" << endl;
                cout << "4. Peek Front" << endl;
                cout << "0. Exit:" << endl;
                cin >> ch;
                clearScreen();
                if (ch == 1)
                {
                    int num;
                    cout << "Enter the number to be inserted at queue:" << endl;
                    cin >> num;
                    q.enqueue(num);
                    if (!askToContinue())
                    {
                        clearScreen();
                        break;
                    }
                }
                else if (ch == 2)
                {
                    q.dequeue();
                    if (!askToContinue())
                    {
                        clearScreen();
                        break;
                    }
                }
                else if (ch == 3)
                {
                    q.print();
                    if (!askToContinue())
                    {
                        clearScreen();
                        break;
                    }
                }
                else if (ch == 4)
                {
                    cout << "Front element in queue is: ";
                    int t = q.peekfront();
                    cout << t << endl;
                    if (!askToContinue())
                    {
                        clearScreen();
                        break;
                    }
                }
                else if (ch == 0)
                {
                    clearScreen();
                    break;
                }
                else
                {
                    cout << "\t\t\t\tInvalid Choice!\n\t\t\t\tTry again." << endl;
                }
            }
        }
        else if (choice == 5)
        {
            cout << "\t\t\t\tSearching Algorithms:" << endl;
            cout << "Enter size of an 1-D array:" << endl;
            int n;
            cin >> n;
            int *arr = new int[n];
            cout << "Enter elements of an 1-D array:" << endl;
            for (int i = 0; i < n; i++)
            {
                cin >> arr[i];
            }
            cout << "Elements of an 1-D array:" << endl;
            for (int i = 0; i < n; i++)
            {
                cout << arr[i] << " ";
            }
            cout << endl;
            clearScreen();
            int key;
            cout << "Enter the key to search in the array:" << endl;
            cin >> key;
            clearScreen();
            while (true)
            {
                cout << "Enter your choice for searching algorithm:" << endl;
                cout << "1. Linear Search" << endl;
                cout << "2. Binary Search" << endl;
                cout << "3. Interpolation Search:" << endl;
                cout << "0. Exit:" << endl;
                int ch;
                cin >> ch;
                clearScreen();
                if (ch == 1)
                {
                    int t = linearSearch(arr, n, key);
                    if (t == -1)
                    {
                        cout << "Element is not present in array" << endl;
                    }
                    else
                    {
                        cout << "Element is present at index " << t << endl;
                    }
                    if (!askToContinue())
                    {
                        clearScreen();
                        break;
                    }
                }
                else if (ch == 2)
                {
                    int t = binarySearch(arr, n, key);
                    if (t == -1)
                    {
                        cout << "Element is not present in array" << endl;
                    }
                    else
                    {
                        cout << "Element is present at index " << t << endl;
                    }
                    if (!askToContinue())
                    {
                        clearScreen();
                        break;
                    }
                }
                else if (ch == 3)
                {
                    int t = interpolationSearch(arr, n, key);
                    if (t == -1)
                    {
                        cout << "Element is not present in array" << endl;
                    }
                    else
                    {
                        cout << "Element is present at index " << t << endl;
                    }
                    if (!askToContinue())
                    {
                        clearScreen();
                        break;
                    }
                }
                else if (ch == 0)
                {
                    clearScreen();
                    break;
                }
                else
                {
                    cout << "\t\t\t\tInvalid Choice!\n\t\t\t\tTry again." << endl;
                }
            }
        }
        else if (choice == 6)
        {
            cout << "\t\t\t\tSorting Alogorithms:" << endl;
            cout << "Enter size of an 1-D array:" << endl;
            int n;
            cin >> n;
            int *arr = new int[n];
            cout << "Enter elements of an 1-D array:" << endl;
            for (int i = 0; i < n; i++)
            {
                cin >> arr[i];
            }
            cout << "Elements of an 1-D array:" << endl;
            for (int i = 0; i < n; i++)
            {
                cout << arr[i] << " ";
            }
            cout << endl;
            clearScreen();
            while (true)
            {
                cout << "Enter your choice for sorting algorithm:" << endl;
                cout << "1. Bubble sort" << endl;
                cout << "2. Selection Sort" << endl;
                cout << "3. Insertion Sort:" << endl;
                cout << "4. Merge Sort:" << endl;
                cout << "5. Quick Sort:" << endl;
                cout << "0. Exit:" << endl;
                int ch;
                cin >> ch;
                clearScreen();
                if (ch == 1)
                {
                    bubble(arr, n);
                    cout << "Elements of an 1-D array:" << endl;
                    for (int i = 0; i < n; i++)
                    {
                        cout << arr[i] << " ";
                    }
                    cout << endl;
                    if (!askToContinue())
                    {
                        clearScreen();
                        break;
                    }
                }
                else if (ch == 2)
                {
                    SelectionSort(arr, n);
                    cout << "Elements of an 1-D array:" << endl;
                    for (int i = 0; i < n; i++)
                    {
                        cout << arr[i] << " ";
                    }
                    cout << endl;
                    if (!askToContinue())
                    {
                        clearScreen();
                        break;
                    }
                }
                else if (ch == 3)
                {
                    InsertionSort(arr, n);
                    cout << "Elements of an 1-D array:" << endl;
                    for (int i = 0; i < n; i++)
                    {
                        cout << arr[i] << " ";
                    }
                    cout << endl;
                    if (!askToContinue())
                    {
                        clearScreen();
                        break;
                    }
                }
                else if (ch == 4)
                {
                    Mergesort(arr, 0, n - 1);
                    cout << "Elements of an 1-D array:" << endl;
                    for (int i = 0; i < n; i++)
                    {
                        cout << arr[i] << " ";
                    }
                    cout << endl;
                    if (!askToContinue())
                    {
                        clearScreen();
                        break;
                    }
                }
                else if (ch == 5)
                {
                    quicksort(arr, 0, n - 1);
                    cout << "Elements of an 1-D array:" << endl;
                    for (int i = 0; i < n; i++)
                    {
                        cout << arr[i] << " ";
                    }
                    cout << endl;
                    if (!askToContinue())
                    {
                        clearScreen();
                        break;
                    }
                }
                else if (ch == 0)
                {
                    clearScreen();
                    break;
                }
                else
                {
                    cout << "\t\t\t\tInvalid Choice!\n\t\t\t\tTry again." << endl;
                }
            }
        }
        else if (choice == 7)
        {
            string text, pattern;
            cout << "Enter the Text:" << endl;
            cin >> text;
            cout << "Enter the Pattern:" << endl;
            cin >> pattern;
            clearScreen();
            cout << "\t\t\t\tString Algorithms:" << endl;
            while (true)
            {
                cout << "Enter your choice:" << endl;
                cout << "1. Brute Force Algorithm:" << endl;
                cout << "2. Rabin Karp Algorithm:" << endl;
                cout << "3. Knuth Morris Pratt Algorithm:" << endl;
                cout << "0. Exit:" << endl;
                int ch;
                cin >> ch;
                clearScreen();
                if (ch == 1)
                {
                    bruteforce(text, pattern);
                    if (!askToContinue())
                    {
                        clearScreen();
                        break;
                    }
                }
                else if (ch == 2)
                {
                    int prime;
                    cout << "Enter the prime number:" << endl;
                    cin >> prime;
                    rabinkarp(text, pattern, prime);
                    if (!askToContinue())
                    {
                        clearScreen();
                        break;
                    }
                }
                else if (ch == 3)
                {
                    KMPSearch(text, pattern);
                    if (!askToContinue())
                    {
                        clearScreen();
                        break;
                    }
                }
                else if (ch == 0)
                {
                    clearScreen();
                    break;
                }
                else
                {
                    cout << "\t\t\t\tInvalid Choice!\n\t\t\t\tTry again." << endl;
                }
            }
        }
        else if (choice == 8)
        {
            bst bst1;
            cout << "\t\t\t\tBinary Search tree operations:" << endl;
            while (true)
            {
                int ch;
                cout << "Enter your choice:" << endl;
                cout << "1. Insert:" << endl;
                cout << "2. Delete:" << endl;
                cout << "3. Search:" << endl;
                cout << "4. Preorder traversal:" << endl;
                cout << "5. Inorder traversal:" << endl;
                cout << "6. Postorder traversal:" << endl;
                cout << "7. Height of a tree:" << endl;
                cout << "0. Exit" << endl;
                cin >> ch;
                clearScreen();
                if (ch == 1)
                {
                    int key;
                    cout << "Enter the key to insert:" << endl;
                    cin >> key;
                    bst1.insert(key);
                    if (!askToContinue())
                    {
                        clearScreen();
                        break;
                    }
                }
                else if (ch == 2)
                {
                    int key;
                    cout << "Enter the key to delete:" << endl;
                    cin >> key;
                    bst1.deletenode(key);
                    if (!askToContinue())
                    {
                        clearScreen();
                        break;
                    }
                }
                else if (ch == 3)
                {
                    int key;
                    cout << "Enter the key to search:" << endl;
                    cin >> key;
                    bst1.search(key);
                    if (!askToContinue())
                    {
                        clearScreen();
                        break;
                    }
                }
                else if (ch == 4)
                {
                    bst1.preorder();
                    if (!askToContinue())
                    {
                        clearScreen();
                        break;
                    }
                }
                else if (ch == 5)
                {
                    bst1.inorder();
                    if (!askToContinue())
                    {
                        clearScreen();
                        break;
                    }
                }
                else if (ch == 6)
                {
                    bst1.postorder();
                    if (!askToContinue())
                    {
                        clearScreen();
                        break;
                    }
                }
                else if (ch == 7)
                {

                    int s = bst1.height();
                    cout << "Height of the tree is: " << s << endl;
                    if (!askToContinue())
                    {
                        clearScreen();
                        break;
                    }
                }
                else if (ch == 0)
                {
                    clearScreen();
                    break;
                }
                else
                {
                    cout << "\t\t\t\tInvalid Choice!\n\t\t\t\tTry again." << endl;
                }
            }
        }
        else if (choice == 9)
        {
            avl avl1;
            cout << "\t\t\t\tAVL tree operations:" << endl;
            while (true)
            {
                int ch;
                cout << "Enter your choice:" << endl;
                cout << "1. Insert:" << endl;
                cout << "2. Delete:" << endl;
                cout << "3. Inorder traversal:" << endl;
                cout << "0. Exit" << endl;
                cin >> ch;
                clearScreen();
                if (ch == 1)
                {
                    int key;
                    cout << "Enter the key to insert:" << endl;
                    cin >> key;
                    avl1.insert(key);
                    if (!askToContinue())
                    {
                        clearScreen();
                        break;
                    }
                }
                else if (ch == 2)
                {
                    int key;
                    cout << "Enter the key to delete:" << endl;
                    cin >> key;
                    avl1.deletenode(key);
                    if (!askToContinue())
                    {
                        clearScreen();
                        break;
                    }
                }
                else if (ch == 3)
                {
                    avl1.inorder();
                    if (!askToContinue())
                    {
                        clearScreen();
                        break;
                    }
                }
                else if (ch == 0)
                {
                    clearScreen();
                    break;
                }
                else
                {
                    cout << "\t\t\t\tInvalid Choice!\n\t\t\t\tTry again." << endl;
                }
            }
        }
        else if (choice == 10)
        {
            cout << "\t\t\t\tRat in a maze(Recursion & backtracking):" << endl;
            while (true)
            {
                cout << "Enter your choice:" << endl;
                cout << "1. Proceed:" << endl;
                cout << "0. Exit" << endl;
                int ch;
                cin >> ch;
                clearScreen();
                if (ch == 1)
                {
                    int n;
                    cout << "Enter the size of the maze: ";
                    cin >> n;

                    int **mazeArr = new int *[n];
                    for (int i = 0; i < n; i++)
                    {
                        mazeArr[i] = new int[n];
                    }

                    cout << "Enter the maze matrix (1 for open, 0 for blocked): " << endl;
                    for (int i = 0; i < n; i++)
                    {
                        for (int j = 0; j < n; j++)
                        {
                            cin >> mazeArr[i][j];
                        }
                    }

                    int **output = new int *[n];
                    for (int i = 0; i < n; i++)
                    {
                        output[i] = new int[n];
                        for (int j = 0; j < n; j++)
                        {
                            output[i][j] = 0;
                        }
                    }

                    if (Maze(mazeArr, 0, 0, n, output))
                    {
                        cout << "Path found: " << endl;
                        for (int i = 0; i < n; i++)
                        {
                            for (int j = 0; j < n; j++)
                            {
                                cout << output[i][j] << " ";
                            }
                            cout << endl;
                        }
                    }
                    else
                    {
                        cout << "No path found." << endl;
                    }
                    for (int i = 0; i < n; i++)
                    {
                        delete[] mazeArr[i];
                        delete[] output[i];
                    }
                    delete[] mazeArr;
                    delete[] output;
                    if (!askToContinue())
                    {
                        clearScreen();
                        break;
                    }
                }
                else if (ch == 0)
                {
                    clearScreen();
                    break;
                }
                else
                {
                    cout << "\t\t\t\tInvalid Choice!\n\t\t\t\tTry again." << endl;
                }
            }
        }
        else if (choice == 11)
        {
            cout << "\t\t\t\tN-Queens(Recursion & backtracking):" << endl;
            while (true)
            {
                cout << "Enter your choice:" << endl;
                cout << "1. Proceed:" << endl;
                cout << "0. Exit" << endl;
                int ch;
                cin >> ch;
                clearScreen();
                if (ch == 1)
                {

                    cout << "Input number for [potential flag placements]: ";
                    int n;
                    cin >> n;
                    if (n <= 0)
                    {
                        cout << "Please enter a positive integer." << endl;
                        return 1;
                    }
                    int *board = new int[n];
                    for (int i = 0; i < n; i++)
                    {
                        board[i] = -1;
                    }
                    if (solve(board, n))
                    {
                        cout << "MAX number of flags that can be placed: " << n << endl;
                        cout << "Board configuration:" << endl;
                        displayBoard(board, n);
                    }
                    else
                    {
                        cout << "NO solution exists" << endl;
                    }

                    delete[] board;
                    if (!askToContinue())
                    {
                        clearScreen();
                        break;
                    }
                }
                else if (ch == 0)
                {
                    clearScreen();
                    break;
                }
                else
                {
                    cout << "\t\t\t\tInvalid Choice!\n\t\t\t\tTry again." << endl;
                }
            }
        }
        else if (choice == 12)
        {
            cout << "\t\t\t\tHashing with Chaining:" << endl;
            hashtablechain ht;
            while (true)
            {
                int ch;
                cout << "Enter your choice:" << endl;
                cout << "1. Insert:" << endl;
                cout << "2. Delete:" << endl;
                cout << "3. Search:" << endl;
                cout << "4. Display:" << endl;
                cout << "0. Exit" << endl;
                cin >> ch;
                clearScreen();
                if (ch == 1)
                {
                    int key;
                    cout << "Enter key to insert: ";
                    cin >> key;
                    ht.insert(key);
                    if (!askToContinue())
                    {
                        clearScreen();
                        break;
                    }
                }
                else if (ch == 2)
                {
                    int key;
                    cout << "Enter key to delete: ";
                    cin >> key;
                    ht.remove(key);
                    if (!askToContinue())
                    {
                        clearScreen();
                        break;
                    }
                }
                else if (ch == 3)
                {
                    int key;
                    cout << "Enter key to search: ";
                    cin >> key;
                    if (ht.search(key))
                    {
                        cout << "Key found in the hash table!" << endl;
                    }
                    else
                    {
                        cout << "Key not found in the hash table!" << endl;
                    }
                    if (!askToContinue())
                    {
                        clearScreen();
                        break;
                    }
                }
                else if (ch == 4)
                {
                    ht.display();
                    if (!askToContinue())
                    {
                        clearScreen();
                        break;
                    }
                }
                else if (ch == 0)
                {
                    clearScreen();
                    break;
                }
                else
                {
                    cout << "\t\t\t\tInvalid Choice!\n\t\t\t\tTry again." << endl;
                }
            }
        }
        else if (choice == 13)
        {
            cout << "\t\t\t\tHashing with Linear Probing:" << endl;
            int n;
            cout << "Enter Capacity for hash table: ";
            cin >> n;
            hashtablelinear ht(n);
            while (true)
            {
                int ch;
                cout << "Enter your choice:" << endl;
                cout << "1. Insert:" << endl;
                cout << "2. Delete:" << endl;
                cout << "3. Search:" << endl;
                cout << "4. Display:" << endl;
                cout << "0. Exit" << endl;
                cin >> ch;
                clearScreen();
                if (ch == 1)
                {
                    int key;
                    cout << "Enter key to insert: ";
                    cin >> key;
                    ht.insert(key);
                    if (!askToContinue())
                    {
                        clearScreen();
                        break;
                    }
                }
                else if (ch == 2)
                {
                    int key;
                    cout << "Enter key to delete: ";
                    cin >> key;
                    ht.remove(key);
                    if (!askToContinue())
                    {
                        clearScreen();
                        break;
                    }
                }
                else if (ch == 3)
                {
                    int key;
                    cout << "Enter key to search: ";
                    cin >> key;
                    if (ht.search(key))
                    {
                        cout << "Key found in the hash table!" << endl;
                    }
                    else
                    {
                        cout << "Key not found in the hash table!" << endl;
                    }
                    if (!askToContinue())
                    {
                        clearScreen();
                        break;
                    }
                }
                else if (ch == 4)
                {
                    ht.display();
                    if (!askToContinue())
                    {
                        clearScreen();
                        break;
                    }
                }
                else if (ch == 0)
                {
                    clearScreen();
                    break;
                }
                else
                {
                    cout << "\t\t\t\tInvalid Choice!\n\t\t\t\tTry again." << endl;
                }
            }
        }
        else if (choice == 14)
        {
            cout << "\t\t\t\tHashing with Quadratic Probing:" << endl;
            int n;
            cout << "Enter Capacity for hash table: ";
            cin >> n;
            hashtablequad ht(n);
            while (true)
            {
                int ch;
                cout << "Enter your choice:" << endl;
                cout << "1. Insert:" << endl;
                cout << "2. Delete:" << endl;
                cout << "3. Search:" << endl;
                cout << "4. Display:" << endl;
                cout << "0. Exit" << endl;
                cin >> ch;
                clearScreen();
                if (ch == 1)
                {
                    int key;
                    cout << "Enter key to insert: ";
                    cin >> key;
                    ht.insert(key);
                    if (!askToContinue())
                    {
                        clearScreen();
                        break;
                    }
                }
                else if (ch == 2)
                {
                    int key;
                    cout << "Enter key to delete: ";
                    cin >> key;
                    ht.remove(key);
                    if (!askToContinue())
                    {
                        clearScreen();
                        break;
                    }
                }
                else if (ch == 3)
                {
                    int key;
                    cout << "Enter key to search: ";
                    cin >> key;
                    if (ht.search(key))
                    {
                        cout << "Key found in the hash table!" << endl;
                    }
                    else
                    {
                        cout << "Key not found in the hash table!" << endl;
                    }
                    if (!askToContinue())
                    {
                        clearScreen();
                        break;
                    }
                }
                else if (ch == 4)
                {
                    ht.display();
                    if (!askToContinue())
                    {
                        clearScreen();
                        break;
                    }
                }
                else if (ch == 0)
                {
                    clearScreen();
                    break;
                }
                else
                {
                    cout << "\t\t\t\tInvalid Choice!\n\t\t\t\tTry again." << endl;
                }
            }
        }
        else if (choice == 15)
        {
            cout << "\t\t\t\tHashing with Double Probing:" << endl;
            int n;
            cout << "Enter Capacity for hash table: ";
            cin >> n;
            hashtabledouble ht(n);
            while (true)
            {
                int ch;
                cout << "Enter your choice:" << endl;
                cout << "1. Insert:" << endl;
                cout << "2. Delete:" << endl;
                cout << "3. Search:" << endl;
                cout << "4. Display:" << endl;
                cout << "0. Exit" << endl;
                cin >> ch;
                clearScreen();
                if (ch == 1)
                {
                    int key;
                    cout << "Enter key to insert: ";
                    cin >> key;
                    ht.insert(key);
                    if (!askToContinue())
                    {
                        clearScreen();
                        break;
                    }
                }
                else if (ch == 2)
                {
                    int key;
                    cout << "Enter key to delete: ";
                    cin >> key;
                    ht.remove(key);
                    if (!askToContinue())
                    {
                        clearScreen();
                        break;
                    }
                }
                else if (ch == 3)
                {
                    int key;
                    cout << "Enter key to search: ";
                    cin >> key;
                    if (ht.search(key))
                    {
                        cout << "Key found in the hash table!" << endl;
                    }
                    else
                    {
                        cout << "Key not found in the hash table!" << endl;
                    }
                    if (!askToContinue())
                    {
                        clearScreen();
                        break;
                    }
                }
                else if (ch == 4)
                {
                    ht.display();
                    if (!askToContinue())
                    {
                        clearScreen();
                        break;
                    }
                }
                else if (ch == 0)
                {
                    clearScreen();
                    break;
                }
                else
                {
                    cout << "\t\t\t\tInvalid Choice!\n\t\t\t\tTry again." << endl;
                }
            }
        }
        else if (choice == 16)
        {
            cout << "\t\t\t\tGraph representation using List" << endl;
            int vertices, edges, u, v;
            cout << "Enter the number of vertices: ";
            cin >> vertices;
            GraphList adjListGraph(vertices);
            while (true)
            {
                int ch;
                cout << "Enter your choice:" << endl;
                cout << "1. Add an edge" << endl;
                cout << "2. Remove an edge" << endl;
                cout << "3. Display the graph" << endl;
                cout << "4. DFS traversal:" << endl;
                cout << "5. BFS traversal:" << endl;
                cout << "0. Exit" << endl;
                cin >> ch;
                clearScreen();
                if (ch == 1)
                {
                    cout << "Enter the number of edges: ";
                    cin >> edges;

                    for (int i = 0; i < edges; i++)
                    {
                        cout << "Enter edge (source destination): ";
                        cin >> u >> v;
                        adjListGraph.addEdge(u, v);
                    }
                    if (!askToContinue())
                    {
                        clearScreen();
                        break;
                    }
                }
                else if (ch == 2)
                {
                    cout << "Enter the number of edges to be removed: ";
                    cin >> edges;
                    for (int i = 0; i < edges; i++)
                    {
                        cout << "Enter edge (source destination): ";
                        cin >> u >> v;
                        adjListGraph.removeEdge(u, v);
                    }
                    if (!askToContinue())
                    {
                        clearScreen();
                        break;
                    }
                }
                else if (ch == 3)
                {
                    cout << "Adjacency List:\n";
                    adjListGraph.display();
                    if (!askToContinue())
                    {
                        clearScreen();
                        break;
                    }
                }
                else if (ch == 4)
                {
                    cout << "DFS Traversal:" << endl;
                    adjListGraph.dfs(0);
                    if (!askToContinue())
                    {
                        clearScreen();
                        break;
                    }
                }
                else if (ch == 5)
                {
                    cout << "BFS Traversal:" << endl;
                    adjListGraph.bfs(0);
                    if (!askToContinue())
                    {
                        clearScreen();
                        break;
                    }
                }
                else if (ch == 0)
                {
                    clearScreen();
                    break;
                }
                else
                {
                    cout << "\t\t\t\tInvalid Choice!\n\t\t\t\tTry again." << endl;
                }
            }
        }
        else if (choice == 17)
        {
            cout << "\t\t\t\tGraph representation using Matrix" << endl;
            int vertices, edges, u, v;
            cout << "Enter the number of vertices: ";
            cin >> vertices;
            GraphMatrix adjMatrixGraph(vertices);
            while (true)
            {
                int ch;
                cout << "Enter your choice:" << endl;
                cout << "1. Add an edge" << endl;
                cout << "2. Remove an edge" << endl;
                cout << "3. Display the graph" << endl;
                cout << "4. DFS traversal:" << endl;
                cout << "5. BFS traversal:" << endl;
                cout << "0. Exit" << endl;
                cin >> ch;
                clearScreen();
                if (ch == 1)
                {
                    cout << "Enter the number of edges: ";
                    cin >> edges;

                    for (int i = 0; i < edges; i++)
                    {
                        cout << "Enter edge (source destination): ";
                        cin >> u >> v;
                        adjMatrixGraph.addEdge(u, v);
                    }
                    if (!askToContinue())
                    {
                        clearScreen();
                        break;
                    }
                }
                else if (ch == 2)
                {
                    cout << "Enter the number of edges to be removed: ";
                    cin >> edges;
                    for (int i = 0; i < edges; i++)
                    {
                        cout << "Enter edge (source destination): ";
                        cin >> u >> v;
                        adjMatrixGraph.removeEdge(u, v);
                    }
                    if (!askToContinue())
                    {
                        clearScreen();
                        break;
                    }
                }
                else if (ch == 3)
                {
                    cout << "Adjacency List:\n";
                    adjMatrixGraph.display();
                    if (!askToContinue())
                    {
                        clearScreen();
                        break;
                    }
                }
                else if (ch == 4)
                {
                    cout << "DFS Traversal:" << endl;
                    adjMatrixGraph.dfs(0);
                    if (!askToContinue())
                    {
                        clearScreen();
                        break;
                    }
                }
                else if (ch == 5)
                {
                    cout << "BFS Traversal:" << endl;
                    adjMatrixGraph.bfs(0);
                    if (!askToContinue())
                    {
                        clearScreen();
                        break;
                    }
                }
                else if (ch == 0)
                {
                    clearScreen();
                    break;
                }
                else
                {
                    cout << "\t\t\t\tInvalid Choice!\n\t\t\t\tTry again." << endl;
                }
            }
        }
        else if (choice == 0)
        {
            cout << "\t\t\t\tProject Ended!" << endl;
            cout << "\t\t\t\tGoodBye!" << endl;
            waitForKeyPress();
            break;
        }
        else
        {
            cout << "\t\t\t\tInvalid Choice!\n\t\t\t\tTry again." << endl;
        }
    }
    return 0;
}