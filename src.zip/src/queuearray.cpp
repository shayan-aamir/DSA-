#include <iostream>
using namespace std;

class Queue
{
public:
    int front, rear, size;
    int *arr;

    Queue() : front(-1), rear(-1), size(0), arr(nullptr) {} // Default constructor

    Queue(int s)
    {
        front = -1;
        rear = -1;
        size = s;
        arr = new int[size];
    }

    void enqueue(int x)
    {
        if (rear == size - 1)
        {
            cout << "Queue is full" << endl;
            return;
        }
        else
        {
            if (front == -1)
            {
                front = 0; // Initialize front if the queue was empty
            }
            rear++;
            arr[rear] = x; // Add element to the rear of the queue
        }
    }

    void dequeue()
    {
        if (isempty())
        {
            cout << "Queue is empty" << endl;
            return;
        }
        else
        {
            cout << "Dequeued: " << arr[front] << endl;
            front++;
            if (front > rear)
            {
                front = rear = -1;
            }
        }
    }

    int peekfront()
    {
        if (isempty())
        {
            cout << "Queue is empty" << endl;
            return -1;
        }
        else
        {
            return arr[front];
        }
    }

    bool isempty()
    {
        return (front == -1);
    }

    ~Queue()
    {
        delete[] arr; // Destructor to free allocated memory
    }

    void print()
    {
        if (isempty())
        {
            cout << "Queue is empty" << endl;
            return;
        }
        cout << "Queue elements: ";
        for (int i = front; i <= rear; ++i)
        {
            cout << arr[i] << " ";
        }
        cout << endl;
    }
};

