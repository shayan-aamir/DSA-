#include <iostream>
using namespace std;
bool isSafe(int **arr, int x, int y, int n)
{
    if (x >= 0 && y >= 0 && x < n && y < n && arr[x][y] == 1)
    {
        return true;
    }
    return false;
}
bool Maze(int **arr, int x, int y, int n, int **output)
{
    if (x == n - 1 && y == n - 1)
    {
        output[x][y] = 1;
        return true;
    }
    if (isSafe(arr, x, y, n))
    {
        output[x][y] = 1;
        if (Maze(arr, x, y + 1, n, output))
        {
            return true;
        }
        if (Maze(arr, x + 1, y, n, output))
        {
            return true;
        }
        output[x][y] = 0;
    }
    return false;
}