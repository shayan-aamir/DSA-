#include <iostream>
#include<cmath>
using namespace std;
class hashtablequad
{
    int *table, size, capacity;
    int hashfunc(int key)
    {
        return key % capacity;
    }

public:
    hashtablequad(int cap)
    {
        size = 0;
        capacity = cap;
        table = new int[capacity];
        for (int i = 0; i < capacity; i++)
        {
            table[i] = -1;
        }
    }
    void insert(int key)
    {
        int idx = hashfunc(key);
        int i = 0;
        if (capacity == size)
        {
            cout << "Hash table is full" << endl;
            return;
        }
        while (table[(idx + i * i) % capacity] != -1)
        {
            i++;
            if (i == size)
            {
                cout << "No available slot for key " << key << endl;
                return;
            }
        }
        table[(idx + i * i) % capacity] = key;
        size++;
    }
    void remove(int key)
    {
        int idx = hashfunc(key);
        int i = 0;
        while (table[(idx + i * i) % capacity] != -1)
        {
            if (table[(idx + i * i) % capacity] == key)
            {
                table[(idx + i * i) % capacity] = -1;
                size--;
                cout << "Key " << key << " removed." << endl;
                return;
            }
            i++;
            if (i == capacity)
            {
                break;
            }
        }
        cout << "Key " << key << " not found." << endl;
    }
    bool search(int key)
    {
        int idx = hashfunc(key);
        int i = 0;
        while (table[(idx + i * i) % capacity] != -1)
        {
            if (table[(idx + i * i) % capacity] == key)
            {
                return true;
            }
            i++;
            if (i == capacity)
            {
                break;
            }
        }
        return false;
    }
    void display()
    {
        cout << "Hash Table:" << endl;
        for (int i = 0; i < capacity; i++)
        {
            if (table[i] == -1)
            {
                cout << "Index " << i << ": Empty" << endl;
            }
            else
            {
                cout << "Index " << i << ": " << table[i] << endl;
            }
        }
    }
};
