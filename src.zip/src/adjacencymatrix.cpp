#include <iostream>
using namespace std;

class GraphMatrix
{
private:
    int **adjMatrix;
    int numVertices;

public:
    GraphMatrix(int vertices)
    {
        numVertices = vertices;
        adjMatrix = new int *[numVertices];
        for (int i = 0; i < numVertices; i++)
        {
            adjMatrix[i] = new int[numVertices];
            for (int j = 0; j < numVertices; j++)
            {
                adjMatrix[i][j] = 0;
            }
        }
    }
    void addEdge(int u, int v)
    {
        if (u >= 0 && u < numVertices && v >= 0 && v < numVertices)
        {
            adjMatrix[u][v] = 1;
            adjMatrix[v][u] = 1;
        }
        else
        {
            cout << "Invalid vertices!" << endl;
        }
    }
    void removeEdge(int u, int v)
    {
        if (u >= 0 && u < numVertices && v >= 0 && v < numVertices)
        {
            adjMatrix[u][v] = 0;
            adjMatrix[v][u] = 0;
        }
        else
        {
            cout << "Invalid vertices!" << endl;
        }
    }
    void display()
    {
        for (int i = 0; i < numVertices; i++)
        {
            for (int j = 0; j < numVertices; j++)
            {
                cout << adjMatrix[i][j] << " ";
            }
            cout << endl;
        }
    }
    void bfs(int start)
    {
        bool *visited = new bool[numVertices];
        int *queue = new int[numVertices]; // Array to simulate queue
        int front = 0, rear = 0;

        visited[start] = true;
        queue[rear++] = start;

        cout << "BFS Traversal: ";
        while (front < rear)
        {
            int vertex = queue[front++];
            cout << vertex << " ";

            for (int i = 0; i < numVertices; i++)
            {
                if (adjMatrix[vertex][i] == 1 && !visited[i])
                {
                    visited[i] = true;
                    queue[rear++] = i;
                }
            }
        }
        cout << endl;
        delete[] visited;
        delete[] queue;
    }

    void dfsUtil(int vertex, bool *visited)
    {
        visited[vertex] = true;
        cout << vertex << " ";

        for (int i = 0; i < numVertices; i++)
        {
            if (adjMatrix[vertex][i] == 1 && !visited[i])
            {
                dfsUtil(i, visited);
            }
        }
    }

    void dfs(int start)
    {
        bool *visited = new bool[numVertices]();
        cout << "DFS Traversal: ";
        dfsUtil(start, visited);
        cout << endl;
        delete[] visited;
    }
    ~GraphMatrix()
    {
        for (int i = 0; i < numVertices; i++)
        {
            delete[] adjMatrix[i];
        }
        delete[] adjMatrix;
    }
};
