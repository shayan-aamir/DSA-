#include <iostream>
#include <string>
using namespace std;
void rabinkarp(string text, string pattern,int prime)
{
    int n = text.length();
    int m = pattern.length();
    int base=256;
    int patternhash=0,texthash=0,h=1;
    for(int i=0;i<m-1;i++){
        h=(h*base)%prime;
    }
    for(int i=0;i<m;i++){
        patternhash=(base*patternhash+pattern[i])%prime;
        texthash=(base*texthash+text[i])%prime;
    }
    for(int i=0;i<=n-m;i++){
        if(patternhash==texthash){
            bool match=true;
            for(int j=0;j<m;j++){
                if(text[i+j]!=pattern[j]){
                    match=false;
                    break;
                }
            }
            if (match){
                cout << "Pattern found at index " << i << endl;}
        }
         if (i < n - m)
        {
            texthash = (base * (texthash - text[i] * h) + text[i + m]) % prime;
            if (texthash < 0)
                texthash += prime;
        }
    }
}