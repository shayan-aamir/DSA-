#include <iostream>
using namespace std;
class chainnode
{
public:
    int key;
    chainnode *next;
    chainnode(int k)
    {
        key = k;
        next = nullptr;
    }
};
class hashtablechain
{
    static const int size = 10;
    chainnode *table[size];
    int hashfunc(int key)
    {
        return key % size;
    }

public:
    hashtablechain()
    {
        for (int i = 0; i < size; i++)
        {
            table[i] = nullptr;
        }
    }
    void insert(int key)
    {
        int idx = hashfunc(key);
        chainnode *newnode = new chainnode(key);
        if (!table[idx])
        {
            table[idx] = newnode;
        }
        else
        {
            chainnode *temp = table[idx];
            while (temp->next)
            {
                temp = temp->next;
            }
            temp->next = newnode;
        }
    }
    bool search(int key)
    {
        int idx = hashfunc(key);
        chainnode *temp = table[idx];
        while (temp)
        {
            if (temp->key == key)
            {
                return true;
            }
            temp = temp->next;
        }
        return false;
    }
    void remove(int key)
    {
        int idx = hashfunc(key);
        chainnode *temp = table[idx];
        chainnode *prev = nullptr;
        while (temp)
        {
            if (temp->key == key)
            {
                if (prev)
                {
                    prev->next = temp->next;
                }
                else
                {
                    table[idx] = temp->next;
                }
                delete temp;
                return;
            }
            prev = temp;
            temp = temp->next;
        }
    }
    void display()
    {
        for (int i = 0; i < size; ++i)
        {
            cout << "Bucket " << i << ": ";
            chainnode *temp = table[i];
            while (temp)
            {
                cout << temp->key << " -> ";
                temp = temp->next;
            }
            cout << "nullptr\n";
        }
    }
};
