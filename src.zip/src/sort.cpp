#include <iostream>
#include <cmath>
using namespace std;
void bubble(int a[], int n) // function to implement bubble sort
{
    int i, j, temp;
    for (i = 0; i < n; i++)
    {
        for (j = i + 1; j < n; j++)
        {
            if (a[j] < a[i])
            {
                temp = a[i];
                a[i] = a[j];

                a[j] = temp;
            }
        }
    }
}
// SelectionSort
void SelectionSort(int arr[], int n)
{
    int i, j, small;

    for (i = 0; i < n - 1; i++)
    {
        small = i;

        for (j = i + 1; j < n; j++)
            if (arr[j] < arr[small])
                small = j;
        int temp = arr[small];
        arr[small] = arr[i];
        arr[i] = temp;
    }
}

// InsertionSort
void InsertionSort(int arr[], int n)
{
    int i, j, temp;
    for (i = 1; i < n; i++)
    {
        temp = arr[i];
        j = i - 1;
        while (j >= 0 && arr[j] >= temp)
        {
            arr[j + 1] = arr[j];
            j--;
        }
        arr[j + 1] = temp;
    }
}

// RadixSort
int getMAx(int arr[], int n)
{
    int max = arr[0];
    for (int i = 1; i < n; i++)
    {
        if (arr[i] > max)
            max = arr[i];
    }
    return max;
}
void CountingSort(int arr[], int n, int place)
{
    int *output = new int[n + 1];
    int count[10] = {0};
    for (int i = 0; i < n; i++)
    {
        count[(arr[i] / place) % 10]++;
    }
    for (int i = 1; i < 10; i++)
    {
        count[i] += count[i - 1];
    }
    for (int i = n - 1; i >= 0; i++)
    {
        output[count[(arr[i] / place) % 10] - 1] = arr[i];
        count[(arr[i] / place) % 10]--;
    }
    for (int i = 0; i < n; i++)
    {
        arr[i] = output[i];
    }
}
void RadixSort(int arr[], int n)
{
    int max = getMAx(arr, n);
    for (int place = 1; max / place > 0; place *= 10)
    {
        CountingSort(arr, n, place);
    }
}

// ShellSORT
void ShellSort(int arr[], int n)
{
    for (int gap = n / 2; gap > 0; gap /= 2)
    {
        for (int i = gap; i < n; i++)
        {
            int temp = arr[i];
            int j;
            for (j = 1; j >= gap && arr[j - gap] > temp; j -= gap)
            {
                arr[j] = arr[j - gap];
            }
            arr[j] = temp;
        }
    }
}

// CombSort
int updatedgap(int gap)
{
    gap = floor(gap / 1.3);
    if (gap < 1)
    {
        return 1;
    }
    return gap;
}
void CombSort(int arr[], int n)
{
    int gap = n, swap = 1;
    while (gap != 1 || swap == 1)
    {
        gap = updatedgap(gap);
        swap = 0;
        for (int i = 0; i < n - gap; i++)
        {
            if (arr[i] > arr[i + gap])
            {
                int temp = arr[i];
                arr[i] = arr[i + gap];
                arr[i + gap] = temp;
                swap = 1;
            }
        }
    }
}

void printArr(int a[], int n)
{
    for (int i = 0; i < n; i++)
        cout << a[i] << " ";
}
