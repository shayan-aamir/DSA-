#include <iostream>
using namespace std;
class SllNode
{
public:
    int data;
    SllNode *next;

    SllNode(int value)
    {
        data = value;
        next = NULL;
    }
};

class SLL
{
private:
    SllNode *head;

public:
    SLL()
    {
        head = NULL;
    }
    SllNode* getHead()
    {
        return head;
    }
    void insertAtBeginning(int value)
    {
        SllNode *newNode = new SllNode(value);
        newNode->next = head;
        head = newNode;
    }

    void insertAtEnd(int value)
    {
        SllNode *newNode = new SllNode(value);

        if (head == NULL)
        {
            head = newNode;
        }
        else
        {
            SllNode *temp = head;
            while (temp->next != NULL)
            {
                temp = temp->next;
            }
            temp->next = newNode;
        }
    }

    void insertAtPosition(int value, int position)
    {
        SllNode *newNode = new SllNode(value);

        if (position == 1)
        {
            newNode->next = head;
            head = newNode;
            return;
        }

        SllNode *temp = head;
        for (int i = 1; i < position - 1 && temp != NULL; i++)
        {
            temp = temp->next;
        }

        if (temp == NULL)
        {
            cout << "Position out of bounds!" << endl;
            delete newNode;
        }
        else
        {
            newNode->next = temp->next;
            temp->next = newNode;
        }
    }

    void deleteFromBeginning()
    {
        if (head == NULL)
        {
            cout << "List is empty!" << endl;
            return;
        }
        SllNode *temp = head;
        head = head->next;
        delete temp;
    }

    void deleteFromEnd()
    {
        if (head == NULL)
        {
            cout << "List is empty!" << endl;
            return;
        }

        if (head->next == NULL)
        {
            delete head;
            head = NULL;
        }
        else
        {
            SllNode *temp = head;
            while (temp->next->next != NULL)
            {
                temp = temp->next;
            }
            delete temp->next;
            temp->next = NULL;
        }
    }

    void deleteFromPosition(int position)
    {
        if (head == NULL)
        {
            cout << "List is empty!" << endl;
            return;
        }

        if (position == 1)
        {
            deleteFromBeginning();
            return;
        }

        SllNode *temp = head;
        for (int i = 1; i < position - 1 && temp->next != NULL; i++)
        {
            temp = temp->next;
        }

        if (temp->next == NULL)
        {
            cout << "Position out of bounds!" << endl;
        }
        else
        {
            SllNode *nodeToDelete = temp->next;
            temp->next = nodeToDelete->next;
            delete nodeToDelete;
        }
    }

    void traverse()
    {
        if (head == NULL)
        {
            cout << "List is empty!" << endl;
            return;
        }

        SllNode *temp = head;
        while (temp != NULL)
        {
            cout << temp->data << " -> ";
            temp = temp->next;
        }
        cout << "NULL" << endl;
    }

    bool search(int value)
    {
        SllNode *temp = head;
        while (temp != NULL)
        {
            if (temp->data == value)
            {
                return true;
            }
            temp = temp->next;
        }
        return false;
    }
};
