#include <iostream>
using namespace std;
class bstnode
{
public:
    int data;
    bstnode *left;
    bstnode *right;
    bstnode(int val)
    {
        data = val;
        left = nullptr;
        right = nullptr;
    }
};
class bst
{
    bstnode *root;
    bstnode *insert(bstnode *root, int val)
    {
        if (root == nullptr)
        {
            return new bstnode(val);
        }
        if (val < root->data)
        {
            root->left = insert(root->left, val);
        }
        else
        {
            root->right = insert(root->right, val);
        }
        return root;
    }
    bstnode *findmin(bstnode *root)
    {
        bstnode *curr = root;
        while (curr && curr->left)
        {
            curr = curr->left;
        }
        return curr;
    }
    bstnode *deletenode(bstnode *root, int val)
    {
        if (root == nullptr)
        {
            return root;
        }
        if (val < root->data)
        {
            root->left = deletenode(root->left, val);
        }
        else if (val > root->data)
        {
            root->right = deletenode(root->right, val);
        }
        else
        {
            if (root->left == nullptr)
            {
                bstnode *temp = root->right;
                delete root;
                return temp;
            }
            if (root->right == nullptr)
            {
                bstnode *temp = root->left;
                delete root;
                return temp;
            }
            bstnode *temp = findmin(root->right);
            root->data = temp->data;
            root->right = deletenode(root->right, temp->data);
        }
        return root;
    }
    bool search(bstnode *root, int key)
    {
        if (root == nullptr)
        {
            return false;
        }
        if (key == root->data)
        {
            return true;
        }
        if (key < root->data)
        {
            return search(root->left, key);
        }
        return search(root->right, key);
    }
    void inorder(bstnode *root)
    {
        if (root == nullptr)
        {
            return;
        }
        inorder(root->left);
        cout << root->data << " ";
        inorder(root->right);
    }
    void preorder(bstnode *root)
    {
        if (root == nullptr)
        {
            return;
        }
        cout << root->data << " ";
        preorder(root->left);
        preorder(root->right);
    }
    void postorder(bstnode *root)
    {
        if (root == nullptr)
        {
            return;
        }
        postorder(root->left);
        postorder(root->right);
        cout << root->data << " ";
    }
    int height(bstnode *root)
    {
        if (root == nullptr)
        {
            return 0;
        }
        int l = height(root->left);
        int r = height(root->right);
        return max(l, r) + 1;
    }
    void printlevel(bstnode *root, int level)
    {
        if (root == nullptr)
        {
            return;
        }
        if (level == 1)
        {
            cout << root->data << " ";
        }
        else
        {
            printlevel(root->left, level - 1);
            printlevel(root->right, level - 1);
        }
    }
    void levelorder(bstnode *root)
    {
        int h = height(root);
        for (int i = 1; i <= h; i++)
        {
            printlevel(root, i);
        }
        cout << endl;
    }

public:
    bst()
    {
        root = nullptr;
    }
    int height()
    {
        return height(root);
    }
    void insert(int key)
    {
        root = insert(root, key);
    }
    void deletenode(int key)
    {
        root = deletenode(root, key);
    }
    bool search(int key)
    {
        return search(root, key);
    }
    void inorder()
    {
        inorder(root);
        cout << endl;
    }
    void preorder()
    {
        preorder(root);
        cout << endl;
    }
    void postorder()
    {
        postorder(root);
        cout << endl;
    }
    void printLevelOrder()
    {
        cout << "Level Order Traversal: ";
        levelorder(root);
    }
};