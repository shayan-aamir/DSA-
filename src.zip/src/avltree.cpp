#include <iostream>
using namespace std;
class avlnode
{
public:
    int data;
    avlnode *left;
    avlnode *right;
    avlnode(int val)
    {
        data = val;
        left = nullptr;
        right = nullptr;
    }
};
class avl
{
    avlnode *root;
    int height(avlnode *root)
    {
        if (root == nullptr)
        {
            return 0;
        }
        int lh = height(root->left);
        int rh = height(root->right);
        return max(lh, rh) + 1;
    }
    int getBalance(avlnode *root)
    {
        if (root == nullptr)
        {
            return 0;
        }
        return height(root->left) - height(root->right);
    }
    avlnode *rightRotate(avlnode *y)
    {
        avlnode *x = y->left;
        avlnode *T2 = x->right;
        x->right = y;
        y->left = T2;
        return x;
    }
    avlnode *leftRotate(avlnode *x)
    {
        avlnode *y = x->right;
        avlnode *T2 = y->left;
        y->left = x;
        x->right = T2;
        return y;
    }
    avlnode *balanceNode(avlnode *root)
    {
        int bal = getBalance(root);
        // left left
        if (bal > 1 && getBalance(root->left) >= 0)
        {
            return rightRotate(root);
        }
        // left right
        if (bal > 1 && getBalance(root->left) < 0)
        {
            root->left = leftRotate(root->left);
            return rightRotate(root);
        }
        // right right
        if (bal < -1 && getBalance(root->right) <= 0)
        {
            return leftRotate(root);
        }
        // right left
        if (bal < -1 && getBalance(root->right) > 0)
        {
            root->right = rightRotate(root->right);
            return leftRotate(root);
        }
        return root;
    }
    avlnode *insert(avlnode *root, int key)
    {
        if (root == nullptr)
        {
            return new avlnode(key);
        }
        if (key < root->data)
        {
            root->left = insert(root->left, key);
        }
        else if (key > root->data)
        {
            root->right = insert(root->right, key);
        }
        else
        {
            return root;
        }
        return balanceNode(root);
    }
    avlnode *minValueNode(avlnode *root)
    {
        avlnode *current = root;
        while (current && current->left)
        {
            current = current->left;
        }
        return current;
    }
    avlnode *deletenode(avlnode *root, int key)
    {
        if (root == nullptr)
        {
            return root;
        }
        if (key < root->data)
        {
            root->left = deletenode(root->left, key);
        }
        else if (key > root->data)
        {
            root->right = deletenode(root->right, key);
        }
        else
        {
            if (root->left == nullptr)
            {
                avlnode *temp = root->right;
                delete root;
                return temp;
            }
            else if (root->right == nullptr)
            {
                avlnode *temp = root->left;
                delete root;
                return temp;
            }
            avlnode *temp = minValueNode(root->right);
            root->data = temp->data;
            root->right = deletenode(root->right, temp->data);
        }
        if (root == nullptr)
        {
            return root;
        }
        return balanceNode(root);
    }
    void inorder(avlnode *root)
    {
        if (root != nullptr)
        {
            inorder(root->left);
            cout << root->data << " ";
            inorder(root->right);
        }
    }
    void printTree(avlnode *root, int space)
    {
        if (root == nullptr)
            return;

        space += 5;
        printTree(root->right, space);
        cout << endl;
        for (int i = 5; i < space; i++)
            cout << " ";
        cout << root->data << "\n";
        printTree(root->left, space);
    }

public:
    avl()
    {
        root = nullptr;
    }
    void insert(int key)
    {
        root = insert(root, key);
    }

    void deletenode(int key)
    {
        root = deletenode(root, key);
    }

    void inorder()
    {
        inorder(root);
        cout << endl;
    }
    void printTree()
    {
        printTree(root, 0);
    }
};
