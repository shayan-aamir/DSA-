#include <iostream>

using namespace std;

// Function to perform linear search
int linearSearch(int arr[], int size, int key)
{
    for (int i = 0; i < size; ++i)
    {
        if (arr[i] == key)
        {
            return i; // Return the index of the found element
        }
    }
    return -1; // Return -1 if the element was not found
}
int binarySearch(int arr[], int size, int target)
{
    int low = 0;
    int high = size - 1;

    while (low <= high)
    {
        int mid = low + (high - low) / 2; // Calculate the middle index

        // Check if target is at mid
        if (arr[mid] == target)
        {
            return mid;
        }
        // If target is smaller, ignore the right half
        else if (arr[mid] > target)
        {
            high = mid - 1;
        }
        // If target is larger, ignore the left half
        else
        {
            low = mid + 1;
        }
    }

    // If we reach here, the element was not present
    return -1;
}
int interpolationSearch(int arr[], int n, int x)
{
    int low = 0, high = (n - 1);

    while (low <= high && x >= arr[low] && x <= arr[high])
    {
        // Calculate the position using interpolation formula
        int pos = low + ((x - arr[low]) * (high - low) / (arr[high] - arr[low]));

        // Check if the element is present at the position
        if (arr[pos] == x)
        {
            return pos;
        }

        // If x is greater, x is in the right subarray
        if (arr[pos] < x)
        {
            low = pos + 1;
        }
        // If x is smaller, x is in the left subarray
        else
        {
            high = pos - 1;
        }
    }

    // Element not found
    return -1;
}