#include <iostream>
using namespace std;

struct GraphNode
{
    int vertex;
    GraphNode *next;
};

class GraphList
{
private:
    int numVertices;
    GraphNode **adjList;

public:
    GraphList(int vertices)
    {
        numVertices = vertices;
        adjList = new GraphNode *[numVertices];
        for (int i = 0; i < numVertices; i++)
        {
            adjList[i] = nullptr;
        }
    }
    void addEdge(int u, int v)
    {
        if (u >= 0 && u < numVertices && v >= 0 && v < numVertices)
        {
            GraphNode *newNode = new GraphNode{v, adjList[u]};
            adjList[u] = newNode;
            newNode = new GraphNode{u, adjList[v]};
            adjList[v] = newNode;
        }
        else
        {
            cout << "Invalid vertices!" << endl;
        }
    }
    void removeEdge(int u, int v)
    {
        if (u >= 0 && u < numVertices && v >= 0 && v < numVertices)
        {
            GraphNode *temp = adjList[u];
            GraphNode *prev = nullptr;
            while (temp != nullptr && temp->vertex != v)
            {
                prev = temp;
                temp = temp->next;
            }
            if (temp != nullptr)
            {
                if (prev == nullptr)
                {
                    adjList[u] = temp->next;
                }
                else
                {
                    prev->next = temp->next;
                }
                delete temp;
            }
            temp = adjList[v];
            prev = nullptr;
            while (temp != nullptr && temp->vertex != u)
            {
                prev = temp;
                temp = temp->next;
            }
            if (temp != nullptr)
            {
                if (prev == nullptr)
                {
                    adjList[v] = temp->next;
                }
                else
                {
                    prev->next = temp->next;
                }
                delete temp;
            }
        }
        else
        {
            cout << "Invalid vertices!" << endl;
        }
    }
    void display()
    {
        for (int i = 0; i < numVertices; i++)
        {
            cout << i << ": ";
            GraphNode *temp = adjList[i];
            while (temp)
            {
                cout << temp->vertex << " -> ";
                temp = temp->next;
            }
            cout << "NULL" << endl;
        }
    }
    void dfsUtil(int vertex, bool visited[])
    {
        visited[vertex] = true;
        cout << vertex << " ";

        GraphNode *temp = adjList[vertex];
        while (temp)
        {
            if (!visited[temp->vertex])
            {
                dfsUtil(temp->vertex, visited);
            }
            temp = temp->next;
        }
    }

    void dfs(int startVertex)
    {
        bool *visited = new bool[numVertices];
        for (int i = 0; i < numVertices; i++)
        {
            visited[i] = false;
        }
        dfsUtil(startVertex, visited);
        delete[] visited;
    }

    void bfs(int startVertex)
    {
        bool *visited = new bool[numVertices];
        int *queue = new int[numVertices];
        int front = 0, rear = 0;

        for (int i = 0; i < numVertices; i++)
        {
            visited[i] = false;
        }

        visited[startVertex] = true;
        queue[rear++] = startVertex;

        while (front < rear)
        {
            int currentVertex = queue[front++];
            cout << currentVertex << " ";

            GraphNode *temp = adjList[currentVertex];
            while (temp)
            {
                if (!visited[temp->vertex])
                {
                    visited[temp->vertex] = true;
                    queue[rear++] = temp->vertex;
                }
                temp = temp->next;
            }
        }
    }
};
