#include <iostream>
using namespace std;
bool isSafe(int *board, int row, int col)
{
    for (int i = 0; i < row; i++)
    {
        if (board[i] == col || abs(board[i] - col) == abs(i - row))
        {
            return false;
        }
    }
    return true;
}
bool solve(int *board, int n, int row = 0)
{
    if (row == n)
    {
        return true;
    }
    for (int col = 0; col < n; col++)
    {
        if (isSafe(board, row, col))
        {
            board[row] = col;
            if (solve(board, n, row + 1))
            {
                return true;
            }
            board[row] = -1;
        }
    }
    return false;
}
void displayBoard(int board[], int n)
{
    for (int i = 0; i < n; i++)
    {
        for (int j = 0; j < n; j++)
        {
            if (board[i] == j)
            {
                cout << "F ";
            }
            else
            {
                cout << "X ";
            }
        }
        cout << endl;
    }
}