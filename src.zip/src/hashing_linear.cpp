#include <iostream>
using namespace std;
class hashtablelinear
{
    int *table, size, capacity;
    int hashfunc(int key)
    {
        return key % capacity;
    }

public:
    hashtablelinear(int cap)
    {
        size = 0;
        capacity = cap;
        table = new int[capacity];
        for (int i = 0; i < capacity; i++)
        {
            table[i] = -1;
        }
    }
    void insert(int key)
    {
        int idx = hashfunc(key);
        if (capacity == size)
        {
            cout << "Hash table is full" << endl;
            return;
        }
        while (table[idx] != -1)
        {
            idx = (idx + 1) % capacity;
        }
        table[idx] = key;
        size++;
    }
    void remove(int key)
    {
        int idx = hashfunc(key);
        int st = idx;
        while (table[idx] != -1)
        {
            if (table[idx] == key)
            {
                table[idx] = -1;
                size--;
                cout << "Key " << key << " removed." << endl;
                return;
            }
            idx = (idx + 1) % capacity;
            if (idx == st)
            {
                break;
            }
        }
        cout << "Key " << key << " not found." << endl;
    }
    bool search(int key)
    {
        int idx = hashfunc(key);
        int st = idx;
        while (table[idx] != -1)
        {
            if (table[idx] == key)
            {
                return true;
            }
            idx = (idx + 1) % capacity;
            if (idx == st)
            {
                break;
            }
        }
        return false;
    }
    void display()
    {
        cout << "Hash Table:" << endl;
        for (int i = 0; i < capacity; i++)
        {
            if (table[i] == -1)
            {
                cout << "Index " << i << ": Empty" << endl;
            }
            else
            {
                cout << "Index " << i << ": " << table[i] << endl;
            }
        }
    }
};
