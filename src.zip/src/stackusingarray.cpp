#include <iostream>
using namespace std;
class stack
{
    int size, top, *arr;

public:
    stack(int n)
    {
        size = n;
        top = -1;
        arr = new int[size];
    }
    void push(int x)
    {
        arr[++top] = x;
    }
    int pop()
    {
        return arr[top--];
    }
    int peek()
    {
        if (isempty())
        {
            cout << "Stack is empty" << endl;
        }
        else
        {
            return arr[top];
        }
    }
    bool isempty()
    {
        return top == -1;
    }
    void print()
    {
        for (int i = 0; i <= top; i++)
        {
            cout << arr[i] << " ";
        }
        cout << endl;
    }
};
