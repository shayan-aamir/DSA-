#include <iostream>
#include <cmath>
using namespace std;
class hashtabledouble
{
    int *table, size, capacity;
    int hashfunc1(int key)
    {
        return key % capacity;
    }
    int hashfunc2(int key)
    {
        return 1 + (key % (capacity - 1));
    }

public:
    hashtabledouble(int cap)
    {
        size = 0;
        capacity = cap;
        table = new int[capacity];
        for (int i = 0; i < capacity; i++)
        {
            table[i] = -1;
        }
    }
    void insert(int key)
    {
        int idx = hashfunc1(key);
        int step = hashfunc2(key);
        int i = 0;
        while (table[(idx + i * step) % capacity] != -1)
        {
            i++;
            if (i == capacity)
            {
                cout << "No available slot for key " << key << endl;
                return;
            }
        }
        table[(idx + i * step) % capacity] = key;
        size++;
    }
    void remove(int key)
    {
        int idx = hashfunc1(key);
        int step = hashfunc2(key);
        int i = 0;
        while (table[(idx + i * step) % capacity] != -1)
        {
            if (table[(idx + i * step) % capacity] == key)
            {
                table[(idx + i * step) % capacity] = -1;
                size--;
                cout << "Key " << key << " removed." << endl;
                return;
            }
            i++;
            if (i == capacity)
            {
                break;
            }
        }
        cout << "Key " << key << " not found." << endl;
    }
    bool search(int key)
    {
        int idx = hashfunc1(key);
        int step = hashfunc2(key);
        int i = 0;
        while (table[(idx + i * step) % capacity] != -1)
        {
            if (table[(idx + i * step) % capacity] == key)
            {
                return true;
            }
            i++;
            if (i == capacity)
            {
                break;
            }
        }
        return false;
    }
    void display()
    {
        cout << "Hash Table:" << endl;
        for (int i = 0; i < size; i++)
        {
            if (table[i] == -1)
            {
                cout << "Index " << i << ": Empty" << endl;
            }
            else
            {
                cout << "Index " << i << ": " << table[i] << endl;
            }
        }
    }
};
